'use strict';

export default {
  workerPath: '{{JSNETWORKX_BUNDLE}}'
};
