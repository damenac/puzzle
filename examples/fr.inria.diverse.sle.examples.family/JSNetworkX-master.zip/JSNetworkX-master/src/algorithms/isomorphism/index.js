'use strict';

import * as isomorph from './isomorph';

export {
  isomorph
}
export * from './isomorph';
