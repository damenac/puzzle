'use strict';

export default class JSNetworkXException {
  constructor(message) {
    this.name = 'JSNetworkXException';
    this.message = message;
  }
}
