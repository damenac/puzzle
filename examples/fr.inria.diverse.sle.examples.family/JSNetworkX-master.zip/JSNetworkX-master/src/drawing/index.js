'use strict';

import svg from './svg';

export {svg};
export * from './svg';
