'use strict';

import merge from 'lodash/object/merge';
export default merge;
