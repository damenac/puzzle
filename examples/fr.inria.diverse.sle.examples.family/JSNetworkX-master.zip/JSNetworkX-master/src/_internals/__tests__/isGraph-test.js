'use strict';

// TODO
export var testIsGraph = {};
