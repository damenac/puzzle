'use strict';
import isPlainObject from 'lodash/lang/isPlainObject';
export default isPlainObject;
