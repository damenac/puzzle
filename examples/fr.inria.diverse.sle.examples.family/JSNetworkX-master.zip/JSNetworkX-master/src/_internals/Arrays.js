'use strict';

import shuffle from 'lodash/collection/shuffle';
import sample from 'lodash/collection/sample';

export default {shuffle, sample};
