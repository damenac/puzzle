'use strict';

export default global.Worker;
