'use strict';
import clone from 'lodash/lang/clone';
export default clone;
