'use strict';
import isBoolean from 'lodash/lang/isBoolean';
export default isBoolean;
